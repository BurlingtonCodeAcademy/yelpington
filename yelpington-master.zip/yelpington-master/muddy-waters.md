# Muddy Waters

**Address**: 184 Main St.

Iced Green Tea is pricey ($3) but very refreshing!


