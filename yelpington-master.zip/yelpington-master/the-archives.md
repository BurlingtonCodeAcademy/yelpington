# The Archives

**Address:** 191 College St, Burlington, VT 05401

**Phone Number:** (802) 448-4333

**Website:** thearchivesbar.com

Bar with old arcade games! Great selection of Pacman/Galaga-era games, 90s games (TMNT arcade game, Simpsons arcade game, etc) and pinball. Token machine accepts both cash and card.